from Common.utils.DBConn import create_mysql_conn, create_redis_connect
from Common.utils.loadFile import *


def read_keyword_value(cursor):
    sql = "select distinct keyword_parameter_value from keyword_value where avail_status = 1"
    cursor.execute(sql)
    rows = cursor.fetchall()
    keyword_value = [item['keyword_parameter_value'] for item in rows]
    return keyword_value


def insert_data_high(redis_client):
    mysql_conn = create_mysql_conn(mysql_config_dict)
    sql = ('select id,source,root_url,priority,method,params,bid_url_prefix,'
           'depth,list_xpath,url_xpath,title_xpath,time_xpath,type_xpath,'
           'request_type,response_type from url_params_more where id = 5')
    mysql_cursor = mysql_conn.cursor()
    mysql_cursor.execute(sql)
    rows = mysql_cursor.fetchall()
    keyword_value_list = read_keyword_value(mysql_cursor)

    data = []
    for row in rows:
        priority = row['priority']

        if row['params']:
            template_str = row['params'][1:-1]
            for key_value in keyword_value_list:
                
                    param = '{{{}}}'.format(template_str.format(keyword=repr(key_value), page=repr(str(1))))

                    row['params'] = param
                    # 爬取关键词
                    row["keyvalue"] = key_value
                    # 爬取页数
                    row["page"] = 1
                    # 参数模板
                    row["params_template"] = template_str

                    data.append(str(row))

        else:

            row["params_template"] = row['root_url']
            row['root_url'] = row['root_url'].replace('${page}', '1')
            row["page"] = 1
            row["keyvalue"] = None
            data.append(str(row))

    with redis_client.pipeline() as pipe:
        pipe.lpush('high:start_urls', *data)
        pipe.execute()
        mysql_cursor.close()
        mysql_conn.close()


def insert_data_low(redis_client):
    mysql_conn = create_mysql_conn(mysql_config_dict)
    sql = ('select id,source,root_url,priority,method,params,bid_url_prefix,depth,list_xpath,url_xpath,title_xpath,time_xpath,type_xpath,request_type,response_type from url_params_more where avail_status=1 and priority < 90')
    mysql_cursor = mysql_conn.cursor()
    mysql_cursor.execute(sql)
    rows = mysql_cursor.fetchall()
    keyword_value_list = read_keyword_value(mysql_cursor)

    data = []
    for row in rows:
        priority = row['priority']

        if row['params']:
            template_str = row['params'][1:-1]
            for key_value in keyword_value_list:
                
                    param = '{{{}}}'.format(template_str.format(keyword=repr(key_value), page=repr(str(1))))

                    row['params'] = param
                    # 爬取关键词
                    row["keyvalue"] = key_value
                    # 爬取页数
                    row["page"] = 1
                    # 参数模板
                    row["params_template"] = template_str

                    data.append(str(row))

        else:

            row["params_template"] = row['root_url']
            row['root_url'] = row['root_url'].replace('${page}', '1')
            row["page"] = 1
            row["keyvalue"] = None
            data.append(str(row))

    with redis_client.pipeline() as pipe:
        pipe.lpush('low:start_urls', *data)
        pipe.execute()
        mysql_cursor.close()
        mysql_conn.close()


def check_redis_queue_high():
    """
    检查redis队列，如果长度小于预设值，则插入数据
    :return:
    """
    redis_client = create_redis_connect(redis_config_dict)
    if redis_client.llen('high:start_urls') <= redis_config_dict['masterRedis']['queThreshold']:
        insert_data_high(redis_client)
    redis_client.close()


def check_redis_queue_low():
    """
    检查redis队列，如果长度小于预设值，则插入数据
    :return:
    """
    redis_client = create_redis_connect(redis_config_dict)
    if redis_client.llen('low:start_urls') <= redis_config_dict['masterRedis']['queThreshold']:
        insert_data_low(redis_client)
    redis_client.close()


if __name__ == '__main__':

    # while True:
    #     try:
    #         print("程序启动了")
            check_redis_queue_high()
        #     check_redis_queue_low()
        # except:
        #     pass
        # time.sleep(1200)
 


