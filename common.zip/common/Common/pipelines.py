# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
from twisted.internet import task
from Common.utils.loadFile import *
from Common.utils.DBConn import create_mysql_conn, create_redis_item_connect
from Common.utils.loadFile import setting_config_dict
from Common.utils.filter import load_filter_words, load_key_words
from Common.utils.DBConn import create_StrictRedis_connect
from bs4 import BeautifulSoup
import requests

class HighPipeline:
    def process_item(self, item, spider):
        return item


class GeneralPineline:

    def __init__(self):
        self.item_pool = []
        self.last_item_pool = []
        self.setup_connections()
        self.setup_timers()

    def setup_connections(self):
        self.redis_client = create_redis_item_connect(redis_config_dict)
        self.mysql_conn = create_mysql_conn(mysql_config=mysql_config_dict)
        self.mysql_cursor = self.mysql_conn.cursor()

    def setup_timers(self):
        settings = setting_config_dict['SETTING']
        self.timer_1 = self.create_timer(self.insert_data_to_redis, settings['INTERVAL'])
        self.timer_2 = self.create_timer(self.fun_pool, settings['POLL_INTERVAL'])
        self.timer_3 = self.create_timer(self.clear_fg_db, settings['CLEAR'])
        self.timer_4 = self.create_timer(self.update_filter_words, 60)

    def create_timer(self, task_func, interval):
        timer = task.LoopingCall(task_func)
        timer.start(interval)
        return timer

    def open_spider(self, spider):
        pass

    def __del__(self):
        self.mysql_cursor.close()
        self.mysql_conn.close()

    def update_filter_words(self):
        self.filter_words = load_filter_words()
        self.key_words = load_key_words()

    def process_item(self, item, spider):
        """
        处理传入的item，更新数据库或进行内容过滤和存储。
        """
        if "request_status" in item.keys():
            # 如果item中包含request_status，则更新数据库中的状态
            self.update_request_status(item)
            return item

        # 处理标题，移除不必要的内容
        title = self.process_title(item)

        # 判断是否应该存储该item
        if self.should_store_item(item, title):
            # 如果网页内容不过滤词过滤，则返回
            # if not self.filter_content(item['url']):
                # return item
            
            # 存储item
            self.store_item(item)

        return item

    def update_request_status(self, item):
        """
        更新数据库中url_params_more表的request_status字段。
        """
        sql = "UPDATE url_params_more SET request_status = %s WHERE id = %s"
        self.mysql_cursor.execute(sql, (item['request_status'], item['id']))
        self.mysql_conn.commit()

    def process_title(self, item):
        """
        处理item中的标题，移除keyvalue相关的内容。
        """
        title = item.get("full_title") or item.get("title")
        keyvalue = item.get("keyvalue")
        
        if keyvalue:
            
            title = title.replace(f"({keyvalue}相关在信息中)", "")
             # 移除标题中包含的（keyvalue相关在信息中）部分
            item['title'] = item['title'].replace(f"({keyvalue}相关在信息中)", "") 

        return title

    def should_store_item(self, item, title):
        """
        判断是否应该存储该item，根据标签和关键字/过滤词逻辑。
        """
        if item.get("keyvalue"):
            # 如果标题中包含任何过滤词，则不存储
            if any(word in title for word in self.filter_words):
                return False
            return True
        else:
            # 如果标题中包含任何过滤词，则不存储
            if any(word in title for word in self.filter_words):
                return False
            # 如果标题中不包含任何关键字，则不存储
            if not any(word in title for word in self.key_words):
                return False
      
            return True
        
    def store_item(self, item):
        """
        存储处理后的item，删除不需要的字段并添加到item池中。
        """
        item.pop('full_title', None)
        self.item_pool.append(str(item))

    def insert_data(self):
        if self.redis_client.llen('bid_info') > 0:
            # 从Redis中获取所有数据
            redis_data = self.redis_client.lrange('bid_info', 0, -1)
            # 将数据反序列化为Python字典列表
            deserialized_data = [eval(item.decode('utf-8')) for item in redis_data]
            # 获取所有字典的键（即数据库表的列名）
            all_keys = list(deserialized_data[0].keys())
            tuple_list = list(map(lambda data: tuple(data.get(key, None) for key in all_keys), deserialized_data))
            sql = "INSERT IGNORE INTO bid_info ({}) VALUES ({})".format(','.join(all_keys),
             ','.join(['%s'] * len(all_keys)))

            try:
                self.mysql_conn.ping(reconnect=True)
                self.mysql_cursor.executemany(sql, tuple_list)
                self.mysql_conn.commit()
                self.redis_client.delete('bid_info')
            except Exception as e:
                self.mysql_conn.rollback()

    def insert_data_to_redis(self):
        if len(self.item_pool) > 0:
            try:
                self.redis_client.ping()
            except Exception as e:
                self.redis_client = create_redis_item_connect(redis_config_dict)
            finally:
                self.redis_client.rpush('bid_info', *self.item_pool)
                self.item_pool.clear()

    def fun_pool(self):
        self.insert_data()
        
    def clear_fg_db(self):
        redis_client = create_StrictRedis_connect(redis_config_dict)
        redis_client.flushdb()
        redis_client.close()

    def filter_content(self,url) -> bool:
        
        
        content = self.get_content_without_a_tags(url)

        list_filter_words = ["施工总承包"]
        # 如果网页内含有施工总承包，则返回False
        if any(word in content for word in list_filter_words):
            return False
        
        return True
    
    def get_content_without_a_tags(self,url):

        # 获取网页内容
        response = requests.get(url)
        response.encoding = 'utf-8'
        content = response.text
        
        # 使用BeautifulSoup解析HTML内容
        soup = BeautifulSoup(content, 'html.parser')
        
        # 查找所有的<a>标签并移除
        for a_tag in soup.find_all('a'):
            a_tag.decompose()

        # 删除空白字符
        content_without_a_tags_and_whitespace = ' '.join(soup.get_text(separator=' ').split())

        return  content_without_a_tags_and_whitespace