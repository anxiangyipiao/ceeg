# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html
import time
from scrapy import signals
from Common.utils.loadFile import *
import requests
import random
from scrapy.downloadermiddlewares.retry import RetryMiddleware
from twisted.internet.error import TimeoutError, TCPTimedOutError, DNSLookupError, ConnectionRefusedError, ConnectionDone, ConnectError, ConnectionLost, SSLError
from twisted.internet import task, reactor
from collections.abc import Iterable

# useful for handling different item types with a single interfaceyl
from itemadapter import is_item, ItemAdapter


class HighSpiderMiddleware:
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the spider middleware does not modify the
    # passed objects.
    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_spider_input(self, response, spider):
        # Called for each response that goes through the spider
        # middleware and into the spider.

        # Should return None or raise an exception.
        return None

    def process_spider_output(self, response, result, spider):
        # Called with the results returned from the Spider, after
        # it has processed the response.

        # Must return an iterable of Request, or item objects.
        for i in result:
            yield i

    def process_spider_exception(self, response, exception, spider):
        # Called when a spider or process_spider_input() method
        # (from other spider middleware) raises an exception.

        # Should return either None or an iterable of Request or item objects.
        pass

    def process_start_requests(self, start_requests, spider):
        # Called with the start requests of the spider, and works
        # similarly to the process_spider_output() method, except
        # that it doesn’t have a response associated.

        # Must return only requests (not items).
        for r in start_requests:
            yield r

    def spider_opened(self, spider):
        spider.logger.info("Spider opened: %s" % spider.name)


class HighDownloaderMiddleware:
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the downloader middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_request(self, request, spider):
        # Called for each request that goes through the downloader
        # middleware.

        # Must either:
        # - return None: continue processing this request
        # - or return a Response object
        # - or return a Request object
        # - or raise IgnoreRequest: process_exception() methods of
        #   installed downloader middleware will be called
        return None

    def process_response(self, request, response, spider):
        # Called with the response returned from the downloader.

        # Must either;
        # - return a Response object
        # - return a Request object
        # - or raise IgnoreRequest
        return response

    def process_exception(self, request, exception, spider):
        # Called when a download handler or a process_request()
        # (from other downloader middleware) raises an exception.

        # Must either:
        # - return None: continue processing this exception
        # - return a Response object: stops process_exception() chain
        # - return a Request object: stops process_exception() chain
        pass

    def spider_opened(self, spider):
        spider.logger.info("Spider opened: %s" % spider.name)


class ProxyMiddleware:
    def process_request(self, request, spider):
        if request.meta.get('retry_flag', None):
            try:
                del request.meta['proxy']
            except:
                pass
        else:
            proxy = self.__get_proxy()
            if proxy:
                request.meta['proxy'] = 'https://' + str(proxy)
        request.headers.setdefault('User-Agent', random.choice(headers_list['USER_AGENT_LIST']))
        return None

    def process_response(self, request, response, spider):
        # Called with the response returned from the downloader.

        # Must either;
        # - return a Response object
        # - return a Request object
        # - or raise IgnoreRequest
        if response.status != 200:
            request.dont_filter = True
            return request
        return response

    def __get_proxy(self):
        response = requests.post(proxy_dict['proxy']['ip'], headers={'token': proxy_dict['proxy']['token']})
        if response.status_code == 200:
            rt_json = response.json()
            proxy = rt_json['data']
            return proxy


class RotateProxyMiddleware(RetryMiddleware):
    def __init__(self, settings):
        super().__init__(settings)
        self.proxy_failure_count = {}

    @classmethod
    def from_crawler(cls, crawler):
        middleware = super().from_crawler(crawler)
        crawler.signals.connect(middleware.spider_opened, signal=signals.spider_opened)
        return middleware

    def spider_opened(self, spider):
        # 初始化失败计数器
        self.proxy_failure_count[spider] = 0

    def process_exception(self, request, exception, spider):
        if isinstance(exception, self.EXCEPTIONS_TO_RETRY) and not request.meta.get(
                "dont_retry", False
        ):
            if request.meta.get("retry_flag", False):
                return None
            request.meta['retry_flag'] = True
            return request


class CustomRetryMiddleware(RetryMiddleware):
    def process_exception(self, request, exception, spider):
        if isinstance(exception, (TimeoutError, TCPTimedOutError, DNSLookupError,
                                  ConnectionRefusedError, ConnectionDone, ConnectError,
                                  ConnectionLost, SSLError)):
            # Don't retry for these exceptions
            return None
        return super().process_exception(request, exception, spider)


class RedisReactivationMiddleware:
    # def __init__(self, crawler):
    #     self.crawler = crawler
    #     settings = crawler.settings
    #
    #
    # @classmethod
    # def from_crawler(cls, crawler):
    #     # 初始化中间件实例时，传递爬虫对象
    #     middleware = cls(crawler)
    #     crawler.signals.connect(middleware.spider_opened, signal=signals.spider_opened)
    #     return middleware
    def spider_opened(self, spider):
        self.spider = spider

    def process_request(self, request, spider):
        return None

    def process_response(self, request=None, response=None, spider=None):
        if response.status != 200:
            request.meta['dont_retry'] = True
        return response

    def process_exception(self, request, exception, spider):
        request.meta['dont_retry'] = True
        return request


# 验证码中间件
class CaptchaMiddleware:
    def __init__(self):
        pass
    
    def process_response(self, request, response, spider):

        if "验证码" in response.text: 

            # 此网站验证码地址，后期可以从request中获取
            captcha_image_url = "https://www.okcis.cn/php/checkUser/yanzhengcode.php"

             # 获取响应头中的Set-Cookie字段，注意这里可能有多个Set-Cookie，所以用getlist获取列表
            cookies_from_header = response.headers.getlist('Set-Cookie')
    
            # 拼接Cookie
            cookies = ''
            for cookie in cookies_from_header:
                # 把cookie转换为字符串  用;拼接
                cookies = cookies + cookie.decode('utf-8') +";"

            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/",
                "Referer": "https://www.okcis.cn/php/checkUser/login.php",
                
            }

            # 获取验证码图片
            captcha_image_data = requests.get(captcha_image_url,headers=header).content

            # 保存验证码图片
            with open("captcha.jpg", "wb") as f:
                f.write(captcha_image_data)
            
          

            # 获得验证码解决方案
            code = 15

            if code:
                # 将验证码解决方案传递给https://www.okcis.cn/php/checkUser/doVerify.php
                data = {
                    "code": code,
                    "result-keyword-and-form": "变压器",
                }
                # 发送验证码解决方案
                response = requests.post("https://www.okcis.cn/php/checkUser/doVerify.php", data=data, headers=header)

                return response
                

                
            else:
                pass
        return response