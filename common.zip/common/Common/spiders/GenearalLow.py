from urllib.parse import urlencode
from scrapy import FormRequest
from scrapy_redis.spiders import RedisSpider
from scrapy_redis.utils import bytes_to_str,TextColor
from scrapy.http import JsonRequest
import scrapy
from Common.utils.time import time_range
from Common.utils.CommonCore import CommonCore
from Common.utils.loadFile import setting_config_dict



class GeneralSpider(RedisSpider):
    
    name = "low"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # 初始化CommonCore类
        self.common_core = CommonCore()

    def spider_idle(self):
        super().spider_idle()

    def make_request_from_data(self, data):
        row_record = bytes_to_str(data, self.redis_encoding)
        row_record = eval(row_record)

        if row_record.get('root_url', None) is None:
            self.logger.warning(f"{TextColor.WARNING}The data from Redis has no url key in push data{TextColor.ENDC}")
            return []

        url = row_record['root_url']
        method = row_record['method']
        if row_record['params'] is not None:
            params = eval(row_record['params'])     
        else:
            params = None
            
        request_type = row_record['request_type']

        metadata = {
            "row_record": row_record,
        }

        if method == "GET":
            if params:
                url = url + urlencode(params)
            return scrapy.Request(url=url, meta=metadata, callback=self.parse, method=method,headers={'Referer': url})

        elif method == "POST":
            if request_type == "json":
                return JsonRequest(url=url, data=params, method=method, meta=metadata, callback=self.parse,headers={'Referer': url})
            elif request_type == "form":
                return FormRequest(url=url, method=method, formdata=params, meta=metadata, callback=self.parse, headers={'Referer': url})

    def parse(self, response):
       
        metadata = response.meta
        
        # response 200 , 插入到数据库
        if response.status != 200:
            yield {"request_status": "website error", "id": metadata['row_record']['id']}
            return

       
        if str(metadata['row_record']['response_type']).lower() == 'json':

            # 如果返回的是json数据
            yield from self.parse_json_response(response, metadata)

        elif str(metadata['row_record']['response_type']).lower() == 'html':
            
            # 如果返回的是html数据
            yield from self.parse_html_response(response, metadata)

    def parse_json_response(self, response, metadata):

            """
            解析JSON响应，并提取数据。
            """
            # 判断是否有下一页,默认爬取下一页
            bool_next_page = True
            json_data = response.json()
            depth = metadata['row_record']['list_xpath'].split(",")

            try:
                totaltime = []
                result = self.get_data_by_path(json_data, depth)
                for index, row_record in enumerate(result):
                    url = self.common_core.get_url(response.url,metadata['row_record']['bid_url_prefix'], row_record[metadata['row_record']['url_xpath']])

                    title = row_record[metadata['row_record']['title_xpath']]
                    # 加上类型
                    if row_record[metadata['row_record']['type_xpath']]:
                        full_title = row_record[metadata['row_record']['type_xpath']] + title
                    else:
                        full_title = None
                    
                    publish_time = row_record[metadata['row_record']['time_xpath']]

                    # 将publish_time转换为datetime类型
                    publish_time = self.common_core.re_date(publish_time)

                    totaltime.append(publish_time)
                    # 可能是标题栏或者无关的信息，跳过
                    if not publish_time:
                        continue

                    if time_range(publish_time):

                        time = publish_time.strftime('%Y-%m-%d')
                        
                        yield {
                                "url": url, "title": title,
                                "full_title": full_title, 
                                "publish_time": time,
                                "keyvalue": metadata['row_record']['keyvalue'],
                                "source": metadata['row_record']['source'],             
                                }
                            
                    else:
                        bool_next_page = False
                        break

                if bool_next_page and totaltime:
                    yield self.push_next_page(metadata)

            except Exception as e:
                yield {"request_status": "parse json error", "id": metadata['row_record']['id']}
               
    def parse_html_response(self, response, metadata):
        """
        解析HTML响应，并提取数据。
        """
        # 判断是否有下一页,默认爬取下一页
        bool_next_page = True
        soup = self.common_core.run_core(response.text)

        try:
            totaltime = []
            for tag in soup:

                url, title,full_title = self.common_core.parse_url(tag)  # 解析url和标题

                # 如果url为空，跳过标题栏等
                if not url:
                    continue

                url = self.common_core.get_url(response.url, metadata['row_record']['bid_url_prefix'], url)  # 获得完整的url

                publish_time = self.common_core.parse_date(tag)  # 获得日期

                totaltime.append(publish_time)
                # 如果日期为空，跳过分页栏等
                if not publish_time:
                    continue

                # 如果时间在最近日期范围内，且不在过滤列表中，继续爬取
                if time_range(publish_time):
                    time = publish_time.strftime('%Y-%m-%d')
                    
                    # if self.filter_content(url):
                    yield {"url": url, "title": title,
                            "full_title": full_title, 
                            "publish_time": time,
                            "keyvalue": metadata['row_record']['keyvalue'],
                            "source": metadata['row_record']['source'],
                          
                            }

                else:
                    bool_next_page = False
                    break

                #如果最后一个时间没有达到预定时间，继续爬取
            if bool_next_page and totaltime:
                yield self.push_next_page(metadata)
        
        except Exception as e:
            yield {"request_status": "xpath error", "id": metadata['row_record']['id']}
   
    def get_data_by_path(self, data, path_rules):

        if not path_rules:
            return data
        if isinstance(data, dict) and path_rules[0] in data:
            return self.get_data_by_path(data[path_rules[0]], path_rules[1:])
        return None

    def push_next_page(self,metadata:dict):

        if metadata['row_record']["params"]:
            metadata['row_record']["page"] = metadata['row_record']["page"] + 1
            
            if setting_config_dict['SETTING']["MODE"] == 1:
                if metadata['row_record']['page'] > metadata['row_record']['depth']:
                    return
            key_value = metadata["row_record"]["keyvalue"]
            template_str = metadata["row_record"]["params_template"]
            params = '{{{}}}'.format(template_str.format(keyword=repr(key_value), page=repr(str(metadata['row_record']["page"])))) 
            params = eval(params)
            
        else:
            # 该页面没有分页
            if "${page}" not in metadata['row_record']['params_template']:
                return

            metadata['row_record']["page"] = metadata['row_record']["page"] + 1
            if setting_config_dict['SETTING']["MODE"] == 1:
                if metadata['row_record']['page'] > metadata['row_record']['depth']:
                    return
            
            metadata['row_record']['root_url'] = metadata['row_record']['params_template'].replace('${page}', str(metadata['row_record']["page"]))
            metadata['row_record']["keyvalue"] = None
            params = None

        url = metadata['row_record']['root_url']
        method = metadata['row_record']['method']
        request_type = metadata['row_record']['request_type']

        if method == "GET":
            if params:
                url = url + urlencode(params)
            return scrapy.Request(url=url, meta=metadata, callback=self.parse, method=method, headers={'Referer': url})

        elif method == "POST":
            if request_type == "json":
                return JsonRequest(url=url, data=params, method=method, meta=metadata, callback=self.parse,headers={'Referer': url})
            elif request_type == "form":
                return FormRequest(url=url, method=method, formdata=params, meta=metadata, callback=self.parse,headers={'Referer': url})
            

    
        
        
