from bs4 import BeautifulSoup, Tag
import numpy as np
import re
from typing import List
from dateutil import parser
from datetime import datetime


class CommonCore(object):

    def __init__(self):

        pass

    def get_init_url(self, rooturl: str) -> str:  # 有http https
        pattern = re.compile(r'(http://|https://)(.*?)/')
        base_url = pattern.search(rooturl).group(1) + pattern.search(rooturl).group(2) + "/"
        return base_url

    def get_base_url(self, rooturl: str, bid_url_prefix: str) -> str:  # 有http https

        # 判断需不需用加url前缀
        base_url = self.get_init_url(rooturl)
        # 如果有bid_url_prefix不是None,则用bid_url_prefix作为base_url
        if bid_url_prefix:
            base_url = bid_url_prefix

        return base_url

    # 获得url
    def get_url(self, rooturl: str, bid_url_prefix: str, url: str) -> str:

        baseurl = self.get_base_url(rooturl, bid_url_prefix)

        if url.startswith("http"):
            return url
        else:
            if url.startswith("/"):
                return baseurl + url[1:]
            else:
                return baseurl + url

    #  替换字符串
    def replace_str(self, source_str: str, regex: str, replace_str='') -> str:

        str_info = re.compile(regex)
        return str_info.sub(replace_str, source_str)

    # re正则处理html
    def re_rules(self, text: str) -> str:

        # 如果含有body结构则正则获得body里的内容
        if re.search(r'<body.*</body>', text, re.S):
            html = re.search(r'<body.*</body>', text, re.S).group(0)
        else:
            html = text

        # 去掉script标签
        html = self.replace_str(html, '(?i)<script(.|\n)*?</script>')  # (?i)忽略大小写
        # 去掉style标签
        html = self.replace_str(html, '(?i)<style(.|\n)*?</style>')
        # 去掉form标签(有些数据放到form里，坑！)
        # html = replace_str(html, '(?i)<form(.|\n)*?</form>')
        # 去掉option标签
        html = self.replace_str(html, '(?i)<option(.|\n)*?</option>')
        # 去掉input标签
        html = self.replace_str(html, '(?i)<input(.|\n)*?>')
        # 去掉img标签
        html = self.replace_str(html, '(?i)<img(.|\n)*?>')
        # 去掉注释
        html = self.replace_str(html, '<!--(.|\n)*?-->')
        # 去掉标签属性
        html = self.replace_str(html, '(?!&[a-z]+=)&[a-z]+;?', ' ')

     

        return html

    # 处理soup
    def process_soup(self, soup: Tag) -> Tag:
        # 去掉文本内容小于7的标签 # 比如<li><a href="http://www.gdtzb.com/kefu/show/33/" id="top-1">入网指导</a></li>的的入网指导长度小于6，舍去
        for tag in soup.find_all('a'):

            # 但是文本里不包括数字
            if len(tag.get_text().strip()) < 6 and not re.search(r'\d', tag.get_text()):
                tag.decompose()

        elements_to_remove = soup.find_all(style="display:none")
        for element in elements_to_remove:
            element.decompose()

        # 去掉空的标签
        for tag in soup.find_all():

            if tag.get_text().strip() == '':
                tag.decompose()

        return soup

    # 判断soup的子节点长度是否为1，是则递归调用，直到子节点长度不为1，返回soup
    def is_single_child_data(self, soup: Tag) -> List[Tag]:

        children = list(soup.children)
        num_children = [child for child in children if child.name is not None]

        if len(num_children) == 1:
            return self.is_single_child_data(num_children[0])
        else:
            return num_children

    # 获得soup最长的孩子节点
    def max_child_data(self, children: List[Tag]) -> Tag:

        max_child = None
        max_length = 0

        # 遍历soup的所有直接子节点
        for child in children:
            if isinstance(child, Tag):
                # 确保它是一个标签
                cleaned_text = re.sub(r"\s+", "", child.get_text(strip=True))
                text_length = len(cleaned_text)  # 获取去除空白后的文本长度

                if text_length > max_length:
                    # 检查这是否是目前找到的最长的文本
                    max_length = text_length
                    max_child = child

        return max_child  # 返回文本最长的子节点，如果没有找到则返回 None

    # 计算item的标准差
    def cal_item_std(self, children: List[Tag]) -> float:

        if not children:
            return None

        # 检查文本长度相似性
        text_lengths = [len(re.sub(r"\s+", "", child.get_text(strip=True))) for child in children]

        # 如果长度text_lengths大于5，省去最小的一个值,这个值可能是标题，分页等，干扰我们的判断
        if len(text_lengths) > 5:
            text_lengths.remove(min(text_lengths))

        num = np.std(text_lengths)

        return num

    # 递归处理soup
    def recursive_process(self, soup: Tag) -> Tag:

        # 检查是否只有一个子节点，如果是则深入
        soup = self.is_single_child_data(soup)

        num = self.cal_item_std(soup)  # 计算newsoup标准差

        len_soup = len(soup)  # 计算soup孩子节点个数

        if num < 66 and len_soup >= 6:
            return soup

        # 在当前层找到最长的子节点
        new_soup = self.max_child_data(soup)

        return self.recursive_process(new_soup)

    #  解析url功能
    def parse_url(self, tag: Tag) -> str:
        
        # 获得tag里所有文本,用于后续判断类别
        full_text = tag.get_text(strip=True)


        # 如果tag是a标签，则直接处理该a标签
        if tag.name == 'a':
            a_tag = tag
        else:
            # 否则查找tag内部的所有a标签
            a_tag = tag.find_all('a') if tag.find_all('a') else None

            if not a_tag:
                return None, None,full_text

            # 获得a标签中文本最长的一个a的href
            a_tag = max(a_tag, key=lambda x: len(x.get_text(strip=True)))

        url = a_tag.get('href')

        if not url:
            return None, None,full_text

        cleaned_link = re.sub(r"\s+", "", url)

        title = a_tag.get_text(strip=True)

        cleaned_title = re.sub(r"\s+", "", title)  # 获得文本最长的title

        return cleaned_link, cleaned_title,full_text

    #   解析日期
    def parse_date(self, tag: Tag) -> datetime:

        text = tag.get_text()

        #    年月日齐全
        date = self.re_date(text)

        #   年月日不齐全，只有月日，没有年份
        if not date:
            text = tag.get_text().split()
            date = self.parser_date(text)

        return date

    # 正则匹配日期   年月日
    def re_date(self, text: str) -> datetime:

        pattern = r"""((?P<year>\d{2,4})[-/.])((?P<month>\d{1,2})[-/.])(?P<day>\d{1,2})"""
        regex = re.compile(pattern, re.VERBOSE)

        # 匹配多个数据的话，返回最早的数据
        data_list = []

        for match in regex.finditer(text):
            year = match.group('year')
            month = match.group('month')
            day = match.group('day')

            if year and month and day:
                try:
                    if len(year) == 2:
                        year = f"20{year}"
                    data_list.append(datetime.strptime(f"{year}-{month}-{day}", "%Y-%m-%d"))
                except:
                    pass
        # 返回最靠近目前时间的日期
        now = datetime.now()
        if data_list:
            return min(data_list, key=lambda x: abs(x - now)).date()
        else:
            return None

    def parser_date(self, text: List) -> datetime:

        extracted_date = None
        for key in text:
            try:
                extracted_date = parser.parse(key, fuzzy=False).date()
                break
            except:
                pass

        return extracted_date

    def run_core(self, response) -> List[Tag]:

        html = self.re_rules(response)  # 正则处理html
        soup = BeautifulSoup(html, 'html.parser')  # 创建soup对象
        soup = self.process_soup(soup)  # 处理soup,空白字符，空标签等

        soup = self.recursive_process(soup)  # 递归处理soup，找到最长的子节点，在递归处理，直到找到我们想要的item

        return soup

    




# #  实例化CommonCore
# commonCore = CommonCore()

# # 每个子标签的文本内容提取出来
# text = [tag.get_text(strip=True) for tag in tag.find_all()]
# text = remove_chinese_characters(text)

# extracted_date = only_one_date(text)


# if not extracted_date:
#     # tag中有多个时间
#     extracted_date = many_date(text)






