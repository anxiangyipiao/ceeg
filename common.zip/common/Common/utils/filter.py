import hashlib
import json
from scrapy_redis.dupefilter import RFPDupeFilter
from Common.utils.DBConn import create_StrictRedis_connect, create_mysql_conn
from Common.utils.loadFile import redis_config_dict, mysql_config_dict


# class ItemFilter:
#     def __init__(self):
#         self.md5 = hashlib.md5()
#         self.redis_client = create_StrictRedis_connect(redis_config_dict)

#     def __del__(self):
#         self.redis_client.close()

#     def filter(self, url):
#         self.md5.update(json.dumps(url).encode('utf-8'))
#         hash_val = self.md5.hexdigest()
#         if self.redis_client.get(hash_val):
#             return True
#         else:
#             self.redis_client.set(hash_val, 1)
#             return False


# itemFilter = ItemFilter()

# 帮我自定义一个过滤器，用于过滤重复url请求
# 1. 过滤器的类名为CustomizedFilter

class CustomizedFilter(RFPDupeFilter):
    def request_seen(self, request):
        return False
    






def load_filter_words():
    conn = create_mysql_conn(mysql_config_dict)
    cursor = conn.cursor()
    sql = " select distinct(filter_value) from filter_words "
    cursor.execute(sql)
    words_list = cursor.fetchall()
    cursor.close()
    conn.close()
    words_list = [d['filter_value'] for d in words_list]
    return words_list


def load_key_words():
    conn = create_mysql_conn(mysql_config_dict)
    cursor = conn.cursor()
    sql = "select distinct keyword_parameter_value from keyword_value where avail_status = 1"
    cursor.execute(sql)
    words_list = cursor.fetchall()
    cursor.close()
    conn.close()
    words_list = [d['keyword_parameter_value'] for d in words_list]
    return words_list
