from datetime import datetime, timedelta
from Common.utils.loadFile import setting_config_dict


def time_range(date):
    date_interval = setting_config_dict['SETTING']['DATE_RANGE']
    current_date = datetime.now().date()
    a = current_date - timedelta(days=date_interval)
    if date < current_date - timedelta(days=date_interval):
        return False
    return True
