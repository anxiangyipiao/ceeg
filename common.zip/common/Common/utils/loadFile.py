import os
import yaml


def load_config(file_name):
    # 加载配置yaml文件中关于代理的配置信息
    current_path = os.getcwd()
    current_path = os.path.join(current_path, 'Common', 'config', file_name)
    config_path = current_path.replace('\\', '/')
    with open(config_path, 'r', encoding='utf-8') as f:
        result = yaml.load(f.read(), Loader=yaml.FullLoader)
    return result


proxy_dict = load_config('proxy.yaml')
headers_list = load_config('headers.yaml')
mysql_config_dict = load_config('mysql.yaml')
redis_config_dict = load_config('redis.yaml')
setting_config_dict = load_config('setting.yaml')
# keyword_config = load_config('keyword.yaml')
