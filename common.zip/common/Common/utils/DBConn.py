import pymysql
import redis
from redis import StrictRedis


def create_mysql_conn(mysql_config):
    mysql_config = mysql_config['mysql']
    conn = pymysql.connect(host=mysql_config['host'],
                           port=mysql_config['port'],
                           user=mysql_config['user'],
                           passwd=mysql_config['password'],
                           db=mysql_config['db'],
                           charset=mysql_config['charset'],
                           cursorclass=pymysql.cursors.DictCursor)
    return conn


def create_mysql_conn_not_dict(mysql_config):
    mysql_config = mysql_config['mysql']
    conn = pymysql.connect(host=mysql_config['host'],
                           port=mysql_config['port'],
                           user=mysql_config['user'],
                           passwd=mysql_config['password'],
                           db=mysql_config['db'],
                           charset=mysql_config['charset'])
    return conn


def create_StrictRedis_connect(redis_config):
    redis_client = StrictRedis(host=redis_config['masterRedis']['host'], port=redis_config['masterRedis']['port'],
                               db=redis_config['masterRedis']['fingerprintDB'])
    return redis_client


def create_redis_connect(redis_config):
    redis_client = redis.Redis(host=redis_config['masterRedis']['host'],
                               port=redis_config['masterRedis']['port'],
                               db=redis_config['masterRedis']['startURLDB'])
    return redis_client


def create_redis_item_connect(redis_config):
    redis_client = redis.Redis(host=redis_config['masterRedis']['host'],
                               port=redis_config['masterRedis']['port'],
                               db=redis_config['masterRedis']['ItemDB'])
    return redis_client
